#pragma once

namespace flecs {

using snapshot_t = ecs_snapshot_t;

struct snapshot;

}
